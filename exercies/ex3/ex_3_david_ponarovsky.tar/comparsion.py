import numpy as np
import pandas as pd
from sklearn.svm import SVC

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D # <--- This is important for 3d plotting
import pandas as pd
from pandas import DataFrame
from plotnine import *

import matplotlib as mpl
import matplotlib.pyplot as plt

from random import random

from models import SVM, LDA, Perceptron


def label_f(weight, bias):
    def _label_f(x):
        return np.sign( np.dot(weight, x) + bias)
    return _label_f

def draw_points(m, label_function=label_f(np.array([0.3, -0.5]), 0.1)):
    def _draw_points_n(m,n):
        return np.random.multivariate_normal(
         np.zeros(n), np.identity(n), m)

    X = _draw_points_n(m, 2)
    y = np.array([ label_function(vec) for vec in X ])
    return X,y

def analyze_clssifiers( ):


    # def generate_line_prec(prec):

    def plot(prec, _svm, X, y):
        plt.scatter( X[y == -1][:,0], X[y == -1][:,1])
        plt.scatter( X[y ==  1][:,0], X[y ==  1][:,1])

        min_x, max_x = min(X[:,0]), max(X[:,0])
        min_y, max_y = min(X[:,1]), max(X[:,1])
        print(min_x, max_x)

        _min_range, _max_range = min(min_x, min_y) , max(max_x, max_y)
        print(prec.W)
        xx = [_min_range, _max_range]

        def get_y(W, _x):
            return -(W[0] + _x * W[1])/ W[2] if W[2]  != 0 else -W[0]

        def get_y_prep(_x):
            return get_y(prec.W, _x )

        def get_y_svm(_x):
            print(_svm.coef_()[0])
            return get_y(_svm.coef_()[0], _x)

        def get_true_y(_x):
            return 0.1/0.5 + 0.3/0.5 * _x

        plt.xlim([_min_range,_max_range])
        plt.ylim([_min_range,_max_range])



        middle = (_min_range + _max_range) /2

        def print_line(msg, _f, _color):
            xx = [_min_range , _max_range ]
            yy = [ _f(_x) for _x in xx  ]
            _x = middle + 2 * (0.5 - random())
            _y =_f(_x)
            plt.plot(xx, yy, color=_color )
            plt.annotate(msg, color=_color,
                  xy=(_x, _y), xycoords='data',
                  xytext=(_x + 0.3 , _y), textcoords='data',
                  arrowprops=dict(arrowstyle="->"))

        print_line("prep", get_y_prep, "C5")
        print_line("svm" , get_y_svm , "C4")
        print_line("true plane" , get_true_y ,"C2")
        plt.title("svm vs prep")
        plt.xlabel("x)")
        plt.ylabel("y")
        plt.show()

    for m in [5, 10, 15, 25, 70]:
        X, y = draw_points(m)
        blues, reds = X[y==1], X[y==-1]
        _modes = [Perceptron(), SVM()]
        for _model in _modes:
            _model.fit(deepcopy(X),y)

        plot( _modes[0], _modes[1], X, y)


def expanded_analyze_clssifiers():
    times, k = 500, 1000
    modles = []
    models_num = 3


    def genrate_real_plane(m):
        _f = label_f(np.array([random(), random()]), random())
        X, y = draw_points(m, label_function=_f )
        while (-1 not in y) or (1 not in y):
             X, y = draw_points(m, label_function= _f)
        return X, y, _f

    def accur(mod, _f, Z):
        _prob = 0
        for x,y in zip(map(_f, Z), mod.predict(Z)):
            if x == y:
                _prob +=1
        return _prob/len(Z)

    def one_iteraion(m):
        _modes = [Perceptron(), SVM(), LDA()]
        X, y, _f = genrate_real_plane(m)
        ret = []
        for _model in _modes:
            _model.fit(deepcopy(X),y)
            Z, _ = draw_points(k)
            ret.append( accur(_model, _f, Z) )
        return np.array(ret)

    def calc_mean_performance(M = [5, 10, 15, 25, 70] ):
        ret = []
        for m in M:
            _mean = np.zeros(models_num)
            for _ in range(times):
                _mean += one_iteraion(m)
            ret.append( _mean/ times )
        return M, np.array( ret )

    m, mean_performance = calc_mean_performance()
    for _model_num, _name  in enumerate(["perc", "svm", "lda"]):
        print(mean_performance)
        plt.plot( m , mean_performance[:,_model_num] )
    plt.legend( ["perc", "svm", "lda"] )
    plt.title("calc_mean_performance")
    plt.xlabel("m (size of the given training data)")
    plt.ylabel("propability of successes")
    plt.show()

if __name__ == "__main__" :
    X,y = draw_points(10)
    #p = Perceptron()


    from copy import deepcopy

    models_class = [ Perceptron, SVM, Logistic, DecisionTree, LDA ]
    models = [ ]
    for mod in models_class:
        models.append( mod( ) )
        print("{} init ".format( type(mod) ))

    for mod in models:
        mod.fit(deepcopy(X),y)
        print("{} fit ".format( type(mod) ))

    for mod in models:
        print(mod.predict(deepcopy(X)))
        print("{} predict ".format( type(mod) ))

    analyze_clssifiers()
    expanded_analyze_clssifiers()
